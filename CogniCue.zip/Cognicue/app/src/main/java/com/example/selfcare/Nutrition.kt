package com.example.selfcare

data class Nutrition(
    val label:String="",
    val quantity:String="",
    val unit:String=""
)
