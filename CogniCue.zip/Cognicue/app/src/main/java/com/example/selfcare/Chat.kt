package com.example.selfcare

data class Chat(
    var message:String="",
    var sender:String="",
    var time:String="",
    )
