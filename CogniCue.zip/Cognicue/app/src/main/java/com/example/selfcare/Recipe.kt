package com.example.selfcare

data class Recipe(
    var image:String="",
    var label:String="",
    var recipe:String=""

)
